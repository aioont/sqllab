
<template>
  <main>
    <div class="flex flex-col items-center justify-center h-[60vh] bg-gradient-to-br from-blue-500 to-purple-500">
      <h1 class="text-4xl font-bold text-white mb-8">Welcome to Connect!</h1>
      <p class="text-xl text-white mb-12">Connect with friends, share your moments, and explore new horizons.</p>
      <div class="flex justify-center space-x-4" v-if="!userStore.user.isAuthenticated">
        
        <a href="/signup/" class="py-3 px-6 bg-white text-blue-500 rounded-full font-semibold shadow-lg hover:shadow-xl transition duration-300 ease-in-out">Sign Up</a>
        <a href="/login/" class="py-3 px-6 bg-white text-blue-500 rounded-full font-semibold shadow-lg hover:shadow-xl transition duration-300 ease-in-out">Login</a>
      </div>
      <div v-else>
          <RouterLink @click="logout" to="/login/" class="py-3 px-6 bg-red-400 text-white rounded-full font-semibold shadow-lg hover:shadow-xl transition duration-300 ease-in-out">
                Logout
          </RouterLink>
      </div>

    </div>
    <p class="bg-purple-200 bg-opacity-75 border border-purple-500 rounded-lg p-8 mt-5 text-center font-bold font-roboto">
      Welcome to Connect, the ultimate platform for global connectivity and communication. As the name suggests, Connect brings people from all walks of life together, allowing them to establish meaningful connections and engage in seamless communication. Whether you are looking to connect with friends, share your experiences, or explore new horizons, Connect provides the perfect space for you to do so. Join our vibrant community and start connecting today!
    </p>
  </main>
</template>

<script>
import axios from 'axios'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

export default {
  setup() {
    const router = useRouter()
    const userStore = useUserStore()

    const logout = () => {
      userStore.logout()
      router.push('/login')
    }

    return {
      userStore,
      logout
    }
  },
}
</script>
