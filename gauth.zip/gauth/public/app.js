function GoogleLogin() {
   const provider = new firebase.auth.GoogleAuthProvider();

   firebase.auth().signInWithPopup(provider)
   .then(result => {
      const user = result.user;
   });
}

document.addEventListener('DOMContentLoaded', event => {

    const app = firebase.app();
    const db = firebase.firestore();

    // Reference the document
    const myPost = db.collection('books').doc('book1');

   // const productsRef = db.collection('books');

  //  const query  = productsRef.where('price', '<=' , 400)

   // query.onSnapshot(products => {

     //     products.forEach(doc => {
       //   const data = doc.data();
        //  document.write(data.author +'<br>'+ data.title + '<br>' + data.price +'<br>')
        //  console.log(data)
//  })

// });

     // Listen to realtime changes 
     myPost.onSnapshot(doc => {

       const data = doc.data();
       console.log(data)

     })
});
